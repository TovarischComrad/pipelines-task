# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pipelines']

package_data = \
{'': ['*'], 'pipelines': ['data/*']}

install_requires = \
['pandas>=1.5.3,<2.0.0', 'prefect>=2.8.0,<3.0.0']

entry_points = \
{'console_scripts': ['prefect = pipelines.prefect_flow:prefect']}

setup_kwargs = {
    'name': 'pipelines',
    'version': '0.1.0',
    'description': '',
    'long_description': 'None',
    'author': 'Владимир Яцулевич',
    'author_email': 'vovas53@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
